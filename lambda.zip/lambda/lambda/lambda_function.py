import json
import boto3
import os
import time

# Klienci AWS
dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

# Nazwy zasobów z env lub default
TABLE_NAME = os.environ.get("DDB_TABLE", "iot-lab-dev-data")
BUCKET_NAME = os.environ.get("S3_BUCKET", "iot-lab-dev-raw-data")

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))

    # Jeżeli payload przyszedł w polu 'message' jako string → parsujemy
    payload = None
    if isinstance(event, dict):
        if "message" in event:
            try:
                payload = json.loads(event["message"])
            except Exception:
                payload = {"raw_message": event["message"]}
        else:
            payload = event
    else:
        payload = {"raw_event": str(event)}

    # Timestamp (dla DynamoDB i klucza S3)
    timestamp = int(time.time())

    # Dane do zapisania w DynamoDB
    item = {
        "device_id": payload.get("device_id", "esp32-weather-001"),
        "timestamp": timestamp,
        "temperature": str(payload.get("temperature", "N/A")),
        "humidity": str(payload.get("humidity", "N/A")),
        "pressure": str(payload.get("pressure", "N/A")),
        "pm2_5": str(payload.get("pm2_5", "N/A")),
        "pm10": str(payload.get("pm10", "N/A")),
        "raw_payload": json.dumps(payload)
    }

    # Zapisz do DynamoDB
    try:
        table = dynamodb.Table(TABLE_NAME)
        table.put_item(Item=item)
        print(f"✅ Zapisano do DynamoDB: {item}")
    except Exception as e:
        print(f"❌ Błąd DynamoDB: {str(e)}")

    # Zapisz surowy JSON do S3
    try:
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=f"{payload.get('device_id','esp32')}/{timestamp}.json",
            Body=json.dumps(payload)
        )
        print(f"✅ Zapisano do S3: {BUCKET_NAME}/{payload.get('device_id')}/{timestamp}.json")
    except Exception as e:
        print(f"❌ Błąd S3: {str(e)}")

    return {
        "statusCode": 200,
        "body": json.dumps("Data processed and stored in DynamoDB + S3")
    }
